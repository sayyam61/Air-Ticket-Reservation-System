package com.app.flightmanagement.exception;

public class UserDoesnotExistException extends RuntimeException {

	public UserDoesnotExistException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public UserDoesnotExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}
