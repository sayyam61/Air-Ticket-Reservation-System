package com.app.flightmanagement.exception;

public class NullAdminException extends RuntimeException {

	public NullAdminException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public NullAdminException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
	
}
